// Declare a Book class here.
//   Time to solo...
public class Book {
  private String bookName;
  private int bookISBN;
  
  
 public Book() {
 bookName="";
 //bookISBN=0;
 
 }
  
   public Book(String b,int n) {
 bookName=b;
 bookISBN=n;
 
 }
  
  
  public void Bookrunner() {
    
    
  }
  
  
  
  
  public void setBookName(String c) {
    
    bookName=c;
    
  }
  
  public void setBookISBN(int a) {
    
    bookISBN=a;
    
  }
  
    public String getBookName() {
    
    return bookName;
  }
  
  public int getBookISBN() {
   
    return bookISBN;
  }
  
  public String toString() {
    return bookName+" "+bookISBN;
  }
  
  
  
  
  
  
}