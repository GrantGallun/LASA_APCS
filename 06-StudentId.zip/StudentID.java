//
public class StudentID {
  
  private String studentfirstname;
  private String studentlastname;
  private int studentid;
  private String studentpassword;
  
  public StudentID() {
  studentfirstname="First";
  studentlastname="Last";
  studentid=0;
  studentpassword="";
  }
  
  public StudentID(String a, String b, int c) {
   
  studentfirstname=a;
  studentlastname=b;
  studentid=c;
    
  }
  
  public void setStudentfirstname(String a) {
  studentfirstname=a;
  }
  
  public void setStudentlastname(String b) {
    studentlastname=b;
  }
  
  public void setStudentid(int c) {
    studentid=c;
  }
  
    public String getStudentfirstname() {
  return studentfirstname;
  }
  
  public String getStudentlastname() {
   return studentlastname;
  }
  
  public int getStudentid() {
    return studentid;
  }
  
  public String getStudentpassword() {
    studentpassword=studentlastname.substring(0,1)+studentid+studentlastname.substring(studentlastname.length()-1);
    return studentpassword;
  }
  
  public String toString() {
    return "Name = " + studentfirstname +" "+ studentlastname+ " Student ID = " + studentid;
  }
  
  
}
