public class Main {
public static void main(String args[]) {

StudentID ada = new StudentID();
System.out.println(ada);
ada.setStudentid(223344);
ada.setStudentfirstname("Ada");
ada.setStudentlastname("Lovelace");
System.out.println(ada);
StudentID Buzz = new StudentID("Buzz", "Lightyear", 123456);
System.out.println(Buzz);
System.out.println(Buzz.getStudentfirstname()+" "+Buzz.getStudentlastname()+" ID = "+ Buzz.getStudentid()+" Password = " + Buzz.getStudentpassword());






}
}

