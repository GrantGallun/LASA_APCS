// REPL.IT requires the root class be named "Main".  Normally you'd call this class
// something more descriptive such as Pages.

import java.util.Scanner;

public class Main 
{
   // main(): program starting point
   public static void main( String[] args ) 
   {
      // set up input scanner
      Scanner scan = new Scanner (System.in);
      // get the age
      System.out.println("Enter your age: ");
      int age;
      age = scan.nextInt();
      // call the pages method to compute the number of pages to be read
      int page = pages(age);
      // display result (pages to be read)
      System.out.println(age + " year olds should read at least " + page + " pages before giving up on a book");
   }
   
   public static int pages(int usersAge) {
     int pages = 100 - usersAge;
     return pages;
   }
}