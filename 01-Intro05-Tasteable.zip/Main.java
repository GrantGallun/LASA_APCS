// REPL.IT requires the root class be named "Main".  Normally you'd call this class
// something more descriptive such as Tasteable.
import java.util.Scanner;

public class Main 
{
   // method main(): program starting point
   public static void main( String[] args ) 
   {
     System.out.print("Enter the shelf life:");
      // set up input scanner
      Scanner scan = new Scanner (System.in);
      
      // get input
      int shelfLife = scan.nextInt();
      scan.nextLine();
      int shelfLife2 = (7+(shelfLife/2));
      // compute tasteable age
      System.out.println(shelfLife + " week shelf life tastes best when it is at least " + shelfLife2 + " weeks old.");
      // display result
      
   }
}