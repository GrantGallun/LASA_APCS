// Try to write the WHOLE program. See if you can define the class and 
// main method from memory.  Remember repl.it requires the class containing
// the main method to be named Main.
import java.util.Scanner;

public class Main{
public static int dripspergallon = 15140;
public static void main(String[] args){
Scanner scan = new Scanner (System.in);
System.out.print("Enter faucet drips per minute");
double dripsperminute = scan.nextDouble();
System.out.print("Enter number of days: ");
int days = scan.nextInt();
System.out.print("A faucet with " + dripsperminute +
" drips per minute over " + days + " days will waste " + gallonsperday(dripsperminute, days) + " gallons of water");
}

public static double gallonsperday(double dripsperminute,int days){
double minutesperday = 24*60;
double gallonsperday = (minutesperday*dripsperminute*days)/dripspergallon;
return gallonsperday;




}





}
//Enter faucet drips per minute: 3.75
//Enter number of days: 30
//A faucet with 3.75 drips per minute over 30 days will waste 10.700132100396301 gallons of water