import java.util.Scanner;
class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner (System.in);
    System.out.println("What is your name?");
    String name;
    name = scan.nextLine();
    System.out.println("Hello " + name + "!");
    System.out.println("How old are you?");
    int age;
    age = scan.nextInt();
    scan.nextLine();
    int months = age*12;
    System.out.println("Your age in months is " + months);
    System.out.println("What is your favorite band?"); 
    String band1;
    band1 = scan.nextLine();
    System.out.println("What is your 2nd favorite band?");
    String band2;
    band2 = scan.nextLine();
    System.out.println("I like " + band1 +  " and " + band2 + " too!!!");
  }
}
