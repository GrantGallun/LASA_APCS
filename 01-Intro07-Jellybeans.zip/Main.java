// Try to write the WHOLE program. See if you can define the class and 
// main method from memory.  Remember repl.it requires the class containing
// the main method to be named Main.
import java.util.Scanner;
public class Main 
{
  public static void main( String[] args ) {
     
     Scanner scan = new Scanner (System.in);
     
     System.out.print("Enter jelly bean length  (cm): ");
     double length = scan.nextDouble();
     
     System.out.print("Enter jelly bean height  (cm): ");
     double height = scan.nextDouble();
     System.out.print("Enter jar size (mL): ");
     int jsize = scan.nextInt();
      System.out.println("Estimate for number of jelly beans with average");
     System.out.println("length "+ length + "cm");
     System.out.println("height "+ height + "cm");
     System.out.println("in a jar of size " + jsize + " mL is");
     int estimate2 = beans(height,length,jsize);
     System.out.print(estimate2);
     

//Enter jar size (mL): 500 
//Estimate for number of jelly beans with average
//length: 1.5385 cm
//height: 0.9230 cm
//in a jar of size 500 mL is
//406
  }
  public static int beans(double height, double length, int jsize) {
    double jsize2= jsize * .698;
     int estimate = (int)(jsize2/(5*Math.PI*length*(Math.pow(height,2) / 24)));
     return estimate; 
  }
}
