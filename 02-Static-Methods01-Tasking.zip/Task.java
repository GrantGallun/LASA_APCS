
// name:
// purpose: experience the thrill of methods

public class Task 
{

	// method favorite(): returns ( ( ( (16 * 65 ) + 12 ) * 72 ) / 68 ) - 1
	public static int favorite() 
	{
		
		return ( ( ( (16 * 65 ) + 12 ) * 72 ) / 68 ) - 1; // change method body to produce correct answer
	}


	// method wasted(): prints line that is number of wasted gallons of water 
	public static void wasted( double r, int d ) 
	{
		 String waste = "A faucet with " + r + " drips per minute over " + d + " days will waste " + (int)((d*r*24*60/15140)+.5)  + " gallons of water.";
		 System.out.println(waste);
	}

	// method count(): returns estimated number of beans in jar
	public static int count( double a, double b, int mL ) 
	{
	  double jsize2 = mL * .698;
		int estimate = (int)(jsize2/(5*Math.PI*a*(Math.pow(b,2) / 24)));
		return estimate; // change method body to produce correct answer
	}    
}
