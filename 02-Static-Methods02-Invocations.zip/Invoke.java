// name:  
// purpose: demonstrate further method prowess

public class Invoke 
{
    public static int piggyBank(int p, int n, int d, int q, int h) { 
	int nickel = n*5;
	int dime = d*10;
	int quarter = q*25;
	int half = h*50;
//System.out.println("invoke.piggyBank( " + p + " " + n + " " + d + " " + q + " " + h + "):" +(p+nickel+dime+quarter+half));
return (p+nickel+dime+quarter+half);
	 // method mp3Sizer(): estimates the number of gB needed to store media
    }
public static int mp3Sizer(int s, int v, int p) {
  double song =((double)s)*3.04;
  double video = ((double)v)*89.3;
  double picture = ((double)p)*1.72;
  int gb = (int)((song+picture+video)/1000+1);
  return gb;
  
}
  
  
  
  
  
  
}

