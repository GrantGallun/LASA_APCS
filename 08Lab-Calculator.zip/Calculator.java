public class Calculator
{
	//instance variables
	private double num1;
	private double num2;
	private char operand;
	
	//default constructor
	public Calculator()
	{
		num1 = 0;
		num2 = 0;
		operand = 0;
	}
	
	//inialization constructor
	Calculator(double a, double b, char c){
	  		num1 = a;
		num2 = b;
		operand = c;
	}
	
	//modifier method for num1
	public void setNum1(double n1)
	{
		num1 = n1;
	}
	
	//modifider method for num2
	public void setNum2(double n2)
	{
		num2 = n2;
	}
	
	//modifier method for operator
public void setOperand(char c){
  operand=c;
}
	
	//accessor method for num1
	public double getNum1()
	{
		return num1;
	}
	
	//accessor method for num2
	public double getNum2()
	{
		return num2;
	}
	
	//accessor method for operator

	public char getoperand()
	{
		return operand;
	}
	
	//Create method to calculate the result
public double result(){
  switch(operand){
    case '*':
      return num1*num2;
      
    case '+':
      return num1+num2;
      
    case '-':
      return num1-num2;
      
    case '/':
      if(num2==0){
        return Double.POSITIVE_INFINITY;
      }
      return num1/num2;
      
    
      
  }
  
  return -1;
}

	
	//Create the toString() method
	
	public String toString(){
	  return num1+" " + operand+ " " + num2+" = "+result();
	}
}