
import java.util.Scanner;

public class Main     //CalculatorRunner
{
	public static void main(String[] args)
	{
		double num1;
		double num2;
		char operator;
		
		//instantiate a Scanner
Scanner scan = new Scanner(System.in);

System.out.print("Enter the operator:");
operator=scan.next().charAt(0);
System.out.print("Enter the first operand:");
num1=scan.nextDouble();
System.out.print("Enter the second operand:");
num2=scan.nextDouble();
		//prompt the user for the operator (how do you read in a character?)
		double Answer;
/*if(operator=='*'){
double answer = num1*num2;
}else if(operator=='+'){*/

		//assign the input from the user to operator variable

		//setup a set of conditions below to determine if the operator is valid
		//get the remaining inputs from the user
		//check for division by zero
		if(operator=='/' && num2==0){
		  System.out.println("Cannot Divide by Zero");
		  System.exit(0);
		}
		//instantiate Calculator object with the values entered by the user
		Calculator Calculator1 = new Calculator(num1,num2,operator);
		//call the toString() method to print the results
System.out.println("result = "+Calculator1.result());
System.out.println(Calculator1.toString());

	}
}
